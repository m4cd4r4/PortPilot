/**
 * PortPilot Renderer - UI Logic
 * Handles all user interactions and state management
 */

// ============ State ============
const state = {
  ports: [],
  apps: [],
  runningApps: [],
  settings: {},
  filter: ''
};

// ============ DOM References ============
const dom = {
  portsList: document.getElementById('ports-list'),
  appsList: document.getElementById('apps-list'),
  portFilter: document.getElementById('port-filter'),
  portCount: document.getElementById('port-count'),
  modal: document.getElementById('modal-app'),
  appForm: document.getElementById('app-form'),
  toastContainer: document.getElementById('toast-container')
};

// ============ Initialization ============
document.addEventListener('DOMContentLoaded', async () => {
  setupEventListeners();
  await loadSettings();
  await loadApps();
  
  if (state.settings.autoScan) {
    await scanPorts();
  }

  // Listen for tray scan trigger
  window.portpilot.on('trigger-scan', scanPorts);
});

// ============ Event Listeners ============
function setupEventListeners() {
  // Header buttons
  document.getElementById('btn-scan').addEventListener('click', scanPorts);
  document.getElementById('btn-add-app').addEventListener('click', () => openAppModal());

  // Tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => switchTab(tab.dataset.tab));
  });

  // Filter
  dom.portFilter.addEventListener('input', (e) => {
    state.filter = e.target.value.toLowerCase();
    renderPorts();
  });

  // Modal
  document.getElementById('modal-close').addEventListener('click', closeModal);
  document.getElementById('btn-cancel').addEventListener('click', closeModal);
  dom.appForm.addEventListener('submit', handleAppSubmit);

  // Settings
  document.getElementById('setting-autoscan').addEventListener('change', saveSettings);
  document.getElementById('setting-interval').addEventListener('change', saveSettings);
  document.getElementById('btn-export').addEventListener('click', exportConfig);
  document.getElementById('btn-import').addEventListener('click', importConfig);

  // Close modal on backdrop click
  dom.modal.addEventListener('click', (e) => {
    if (e.target === dom.modal) closeModal();
  });
}

// ============ Tab Navigation ============
function switchTab(tabId) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  
  document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
  document.getElementById(`tab-${tabId}`).classList.add('active');

  // Refresh data when switching tabs
  if (tabId === 'ports') scanPorts();
  if (tabId === 'apps') loadApps();
}

// ============ Port Operations ============
async function scanPorts() {
  const btn = document.getElementById('btn-scan');
  btn.disabled = true;
  btn.innerHTML = '<span class="icon">⏳</span> Scanning...';

  try {
    const result = await window.portpilot.ports.scan();
    if (result.success) {
      state.ports = result.ports.sort((a, b) => a.port - b.port);
      renderPorts();
      showToast(`Found ${state.ports.length} active ports`, 'success');
    } else {
      showToast('Failed to scan ports: ' + result.error, 'error');
    }
  } catch (error) {
    showToast('Scan error: ' + error.message, 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<span class="icon">🔄</span> Scan Ports';
  }
}

function renderPorts() {
  const filtered = state.ports.filter(p => {
    if (!state.filter) return true;
    const searchStr = `${p.port} ${p.processName || ''} ${p.commandLine || ''}`.toLowerCase();
    return searchStr.includes(state.filter);
  });

  dom.portCount.textContent = `${filtered.length} port${filtered.length !== 1 ? 's' : ''}`;

  if (filtered.length === 0) {
    dom.portsList.innerHTML = `<div class="empty-state">
      ${state.ports.length === 0 ? 'No active ports found. Click "Scan Ports" to refresh.' : 'No ports match your filter.'}
    </div>`;
    return;
  }

  dom.portsList.innerHTML = filtered.map(p => `
    <div class="port-card" data-port="${p.port}">
      <div class="port-header">
        <span class="port-number">:${p.port}</span>
        <div class="port-actions">
          <button class="btn btn-small btn-secondary" onclick="copyPort(${p.port})" title="Copy">📋</button>
          <button class="btn btn-small btn-danger" onclick="killPort(${p.port})" title="Kill">✕</button>
        </div>
      </div>
      <div class="port-info">
        <div class="port-info-row">
          <span class="label">Process:</span>
          <span class="value">${escapeHtml(p.processName || 'Unknown')}</span>
        </div>
        <div class="port-info-row">
          <span class="label">PID:</span>
          <span class="value">${p.pid || 'N/A'}</span>
        </div>
        ${p.commandLine ? `
        <div class="port-info-row">
          <span class="label">Command:</span>
          <span class="value">${escapeHtml(truncate(p.commandLine, 60))}</span>
        </div>` : ''}
      </div>
    </div>
  `).join('');
}

async function killPort(port) {
  if (!confirm(`Kill process on port ${port}?`)) return;

  const result = await window.portpilot.ports.kill(port);
  if (result.success) {
    showToast(`Killed process on port ${port}`, 'success');
    await scanPorts();
  } else {
    showToast('Failed to kill: ' + result.error, 'error');
  }
}

function copyPort(port) {
  navigator.clipboard.writeText(`localhost:${port}`);
  showToast(`Copied localhost:${port}`, 'success');
}

// ============ App Operations ============
async function loadApps() {
  try {
    const [configResult, runningResult] = await Promise.all([
      window.portpilot.config.getApps(),
      window.portpilot.process.list()
    ]);

    if (configResult.success) state.apps = configResult.apps;
    if (runningResult.success) state.runningApps = runningResult.apps;

    renderApps();
  } catch (error) {
    showToast('Failed to load apps: ' + error.message, 'error');
  }
}

function renderApps() {
  if (state.apps.length === 0) {
    dom.appsList.innerHTML = `<div class="empty-state">
      No apps registered. Click "Add App" to register your first app.
    </div>`;
    return;
  }

  dom.appsList.innerHTML = state.apps.map(app => {
    const running = state.runningApps.find(r => r.id === app.id && r.running);
    return `
      <div class="app-card" data-id="${app.id}">
        <div class="app-info">
          <div class="app-name">
            <span class="app-color" style="background: ${app.color}"></span>
            ${escapeHtml(app.name)}
          </div>
          <div class="app-meta">
            <code>${escapeHtml(app.command)}</code>
            ${app.preferredPort ? ` • Port ${app.preferredPort}` : ''}
          </div>
        </div>
        <span class="app-status ${running ? 'status-running' : 'status-stopped'}">
          ${running ? '● Running' : '○ Stopped'}
        </span>
        <div class="app-actions">
          ${running 
            ? `<button class="btn btn-small btn-danger" onclick="stopApp('${app.id}')">Stop</button>`
            : `<button class="btn btn-small btn-primary" onclick="startApp('${app.id}')">Start</button>`
          }
          <button class="btn btn-small btn-secondary" onclick="editApp('${app.id}')">Edit</button>
          <button class="btn btn-small btn-secondary" onclick="deleteApp('${app.id}')">🗑</button>
        </div>
      </div>
    `;
  }).join('');
}

async function startApp(appId) {
  const app = state.apps.find(a => a.id === appId);
  if (!app) return;

  showToast(`Starting ${app.name}...`, 'success');
  
  const result = await window.portpilot.process.start(app);
  if (result.success) {
    showToast(`${app.name} started (PID: ${result.pid})`, 'success');
  } else {
    showToast(`Failed to start: ${result.error}`, 'error');
  }
  
  await loadApps();
}

async function stopApp(appId) {
  const result = await window.portpilot.process.stop(appId);
  if (result.success) {
    showToast('App stopped', 'success');
  } else {
    showToast('Failed to stop: ' + result.error, 'error');
  }
  await loadApps();
}

function editApp(appId) {
  const app = state.apps.find(a => a.id === appId);
  if (app) openAppModal(app);
}

async function deleteApp(appId) {
  const app = state.apps.find(a => a.id === appId);
  if (!app || !confirm(`Delete "${app.name}"?`)) return;

  const result = await window.portpilot.config.deleteApp(appId);
  if (result.success) {
    showToast('App deleted', 'success');
    await loadApps();
  } else {
    showToast('Failed to delete: ' + result.error, 'error');
  }
}

// ============ Modal ============
function openAppModal(app = null) {
  document.getElementById('modal-title').textContent = app ? 'Edit App' : 'Add App';
  document.getElementById('app-id').value = app?.id || '';
  document.getElementById('app-name').value = app?.name || '';
  document.getElementById('app-command').value = app?.command || '';
  document.getElementById('app-cwd').value = app?.cwd || '';
  document.getElementById('app-port').value = app?.preferredPort || '';
  document.getElementById('app-fallback').value = app?.fallbackRange ? 
    `${app.fallbackRange[0]}-${app.fallbackRange[1]}` : '';
  document.getElementById('app-autostart').checked = app?.autoStart || false;
  
  dom.modal.classList.remove('hidden');
  document.getElementById('app-name').focus();
}

function closeModal() {
  dom.modal.classList.add('hidden');
  dom.appForm.reset();
}

async function handleAppSubmit(e) {
  e.preventDefault();

  const fallbackStr = document.getElementById('app-fallback').value;
  let fallbackRange = null;
  if (fallbackStr) {
    const match = fallbackStr.match(/(\d+)\s*-\s*(\d+)/);
    if (match) fallbackRange = [parseInt(match[1]), parseInt(match[2])];
  }

  const appConfig = {
    id: document.getElementById('app-id').value || undefined,
    name: document.getElementById('app-name').value,
    command: document.getElementById('app-command').value,
    cwd: document.getElementById('app-cwd').value,
    preferredPort: parseInt(document.getElementById('app-port').value) || null,
    fallbackRange,
    autoStart: document.getElementById('app-autostart').checked
  };

  const result = await window.portpilot.config.saveApp(appConfig);
  if (result.success) {
    showToast('App saved', 'success');
    closeModal();
    await loadApps();
  } else {
    showToast('Failed to save: ' + result.error, 'error');
  }
}

// ============ Settings ============
async function loadSettings() {
  const result = await window.portpilot.config.getSettings();
  if (result.success) {
    state.settings = result.settings;
    document.getElementById('setting-autoscan').checked = state.settings.autoScan !== false;
    document.getElementById('setting-interval').value = state.settings.scanInterval / 1000 || 5;
  }
}

async function saveSettings() {
  const settings = {
    autoScan: document.getElementById('setting-autoscan').checked,
    scanInterval: parseInt(document.getElementById('setting-interval').value) * 1000
  };
  
  await window.portpilot.config.updateSettings(settings);
  state.settings = settings;
  showToast('Settings saved', 'success');
}

async function exportConfig() {
  const result = await window.portpilot.config.export();
  if (result.success) {
    const blob = new Blob([result.data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'portpilot-config.json';
    a.click();
    URL.revokeObjectURL(url);
    showToast('Config exported', 'success');
  }
}

async function importConfig() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const text = await file.text();
    const result = await window.portpilot.config.import(text);
    if (result.success) {
      showToast('Config imported', 'success');
      await loadApps();
    } else {
      showToast('Import failed: ' + result.error, 'error');
    }
  };
  input.click();
}

// ============ Utilities ============
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  dom.toastContainer.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 200);
  }, 3000);
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[m]));
}

function truncate(str, len) {
  if (!str || str.length <= len) return str;
  return str.slice(0, len) + '...';
}

// Expose functions for onclick handlers
window.killPort = killPort;
window.copyPort = copyPort;
window.startApp = startApp;
window.stopApp = stopApp;
window.editApp = editApp;
window.deleteApp = deleteApp;
